package com.xxl.job.executor.sample.frameless.test;

import org.junit.jupiter.api.Test;

public class FramelessApplicationTest {

    @Test
    public void test(){
        System.out.println("111");
    }

}
